/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs_1760_pgm4_cws34;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Polyline;

/**
 *
 * @author Chris
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Button Draw_Button;

    @FXML
    private Button Clear_Screen;

    @FXML
    private Button Delete_Button;
    
    @FXML
    private Pane drawPane;
    

    private enum Draw {FIRST, ON, OFF}
    private Draw draw = Draw.OFF;
    private ObservableList<Polygon> shapes = FXCollections.observableArrayList();
    private ObservableList<Double> points;
    private Polyline lines = new Polyline();
    private Double x,y, prevX, prevY;
    private Polygon poly;
      
    @FXML
    void Draw_Click(ActionEvent event) {
        draw = Draw.ON;
        //lines = new Polyline();
        poly = new Polygon();
        poly.setStrokeWidth(3.0);
        poly.setStroke(Color.BLACK);
        poly.setFill(Color.TRANSPARENT);
        drawPane.getChildren().add(poly);
        points = FXCollections.observableArrayList();
        System.out.println("Omae wa mou shindeiru");
        Clear_Screen.setDisable(false);
    }
    
    @FXML
    void mouseClick(MouseEvent event) {
        if(draw == Draw.OFF){
            //select shape logic
        }else{
            if(event.getClickCount() == 2){
                draw = Draw.OFF;
            }else{
                System.out.println("Nani?");
                x = event.getX();
                y = event.getY();
                points.add(x);
                points.add(y);
                poly.getPoints().addAll(x,y);
                System.out.println(points);
            }
        }
    }

    @FXML
    void Delete_Click(ActionEvent event) {

    }

    @FXML
    void Clear_click(ActionEvent event) {
        drawPane.getChildren().clear();
        Clear_Screen.setDisable(true);
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
